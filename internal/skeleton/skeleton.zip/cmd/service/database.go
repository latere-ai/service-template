package main

import (
	"context"
	"log/slog"

	"example.com/service/internal/server"
	"example.com/service/internal/store"
)

// This file is present when the repository selected the database feature. It
// assigns the seam the entry point calls, so the entry point itself never names
// the store package and compiles without it.
func init() { openDatabase = connectStore }

// storeHandle is what the entry point holds of an open store: the readiness
// check it registers and the close it runs on shutdown.
type storeHandle interface {
	Ping(context.Context) error
	Close()
}

// openStore opens the store the serving path uses. It is a variable so the
// start-up tests can assemble the process around a store that needs no
// server, which is the only way the path after a successful open runs in a
// suite with no database beside it.
var openStore = func(ctx context.Context, dsn string) (storeHandle, error) {
	db, err := store.Open(ctx, dsn)
	if err != nil {
		return nil, err
	}
	return db, nil
}

// connectStore opens the pool, reports it through readiness, and closes it on
// shutdown.
//
// Migrations are not applied here. Two replicas starting at once would race,
// and a start-up migration ties a schema change to rollout timing instead of to
// the deployment step that owns it. They run through the migrate command.
func connectStore(ctx context.Context, a *assembly) error {
	// The serving path connects through the pooler when one is configured, so
	// a replica holds pooler connections rather than server slots and the
	// replica count stops being a database decision. The direct string is the
	// fallback, and stays the migrate command's: a migration holds a
	// session-scoped lock, which a transaction-mode pooler does not keep.
	dsn := a.cfg.DatabasePoolURL.Reveal()
	if dsn == "" {
		dsn = a.cfg.DatabaseURL.Reveal()
	}
	if dsn == "" {
		// A scaffold runs without a database, and so do its tests. A service
		// that requires one states that by making the connection string a
		// required setting in internal/config.
		a.logger.Warn("no database connection string, the store is not opened")
		return nil
	}

	db, err := openStore(ctx, dsn)
	if err != nil {
		return err
	}

	a.addComponent(server.Component{
		Name:  "store",
		Start: func(context.Context) error { return nil },
		Stop: func(context.Context) error {
			// Close blocks until every acquired connection is returned, so a
			// leaked acquisition shows up as a slow shutdown rather than as a
			// connection the server drops mid-query.
			db.Close()
			return nil
		},
	})
	// Readiness reports the pool, not the process: a database the service
	// cannot reach must take the replica out of the load balancer without
	// restarting it, which is what separates ready from live.
	a.addReadyCheck("store", db.Ping)

	slog.InfoContext(ctx, "store connected")
	return nil
}
